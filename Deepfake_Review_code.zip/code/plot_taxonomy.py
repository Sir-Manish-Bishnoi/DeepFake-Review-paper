import sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

OUT = sys.argv[1]
plt.rcParams.update({"font.family": "serif", "font.size": 6.4})
fig, ax = plt.subplots(figsize=(7.1, 2.9)); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")
C = {"in": "#F2F2F2", "sp": "#D55E00", "fr": "#CC79A7", "tm": "#E69F00", "bh": "#0072B2", "st": "#009E73"}


def box(x, y, w, h, text, fc, tc="black", bold=False, ec="#444"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.25,rounding_size=0.8", fc=fc, ec=ec, lw=0.6))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", color=tc, fontweight="bold" if bold else "normal", linespacing=1.15)


def arrow(x1, y1, x2, y2):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", lw=0.6, color="#444", mutation_scale=7))


# input pipeline (left)
box(0.3, 31, 12, 6, "Input video\n$N$ frames", C["in"])
box(0.3, 21.5, 12, 6, "Sample $T$ frames\n(uniform)", C["in"])
box(0.3, 12, 12, 6, "Detect, align and\ncrop the face", C["in"])
arrow(6.3, 31, 6.3, 27.8); arrow(6.3, 21.5, 6.3, 18.3)
arrow(12.6, 15, 17.0, 15)

# families
fams = [
    ("Frame-level\nspatial", "sp", "One frame at a time;\nvideo score = mean\nof frame scores", "Xception\nEfficientNet\nFace X-ray, SBI"),
    ("Frequency\ndomain", "fr", "Spectral or wavelet\ntraces left by\nup-sampling", "F3-Net, SPSL\nspectral\nclassifiers"),
    ("Temporal\n(clip-based)", "tm", "Short clips; motion,\nflicker and texture\nchange over time", "CNN-GRU\nFTCN\nAltFreezing"),
    ("Behavioral &\nphysiological", "bh", "Lip motion, blinking,\npulse signal (rPPG)", "LipForensics\nRealForensics\nFakeCatcher"),
    ("Spatio-temporal\ntransformer", "st", "Attention across\npatches and\nframes", "ViViT, ISTVT\nTALL, TALL++"),
]
w, gap = 15.0, 1.4
for i, (name, k, what, ex) in enumerate(fams):
    x = 17.5 + i * (w + gap)
    box(x, 31, w, 6, name, C[k], tc="white", bold=True, ec=C[k])
    box(x, 20, w, 8, what, "white", ec=C[k])
    box(x, 8.5, w, 8.5, ex, "white", ec="#999")
    arrow(x + w / 2, 31, x + w / 2, 28.3); arrow(x + w / 2, 20, x + w / 2, 17.3)
ax.text(17.5, 4.2, "Cue: artifacts inside a single frame", fontsize=6.2, color="#555", ha="left")
ax.text(99.5, 4.2, "Cue: consistency across frames", fontsize=6.2, color="#555", ha="right")
ax.annotate("", xy=(99.5, 2.4), xytext=(17.5, 2.4), arrowprops=dict(arrowstyle="<|-|>", lw=0.7, color="#777", mutation_scale=7))
ax.text(0.3, 9.5, "Rows: family;\nwhat it looks at;\nexample methods", fontsize=6.0, color="#555", va="top")
fig.tight_layout(pad=0.1)
fig.savefig(f"{OUT}/fig_taxonomy.pdf"); fig.savefig(f"{OUT}/fig_taxonomy.png", dpi=300)
