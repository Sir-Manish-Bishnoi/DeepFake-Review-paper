import json, sys, collections
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

B = sys.argv[1]; OUT = sys.argv[2]
plt.rcParams.update({"font.family": "serif", "font.size": 7.5, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "savefig.dpi": 300})
main = json.load(open(f"{B}/out/results.json"))
GC = {"G1": "#D55E00", "G2": "#0072B2", "G3": "#009E73"}
GN = {"G1": "G1 transposed conv.", "G2": "G2 resize-conv.", "G3": "G3 bicubic"}

fig, axs = plt.subplots(1, 3, figsize=(7.1, 2.25))
# (a) spectra difference
pr = main["profiles"]; real = np.array(pr["real"]); f = np.arange(len(real)) / (2 * len(real))  # cycles/pixel, 0..0.5
ax = axs[0]
for g in ["G1", "G2", "G3"]:
    ax.plot(f[1:], (np.array(pr[g]) - real)[1:], color=GC[g], lw=1.1, label=GN[g])
ax.plot(f[1:], (np.array(pr["G1_q50"]) - np.array(pr["real_q50"]))[1:], color=GC["G1"], lw=1.0, ls="--", label="G1 after JPEG Q50")
ax.set_ylim(-0.85, 0.85)
ax.axhline(0, color="#999", lw=0.5)
ax.set_xlabel("Spatial frequency (cycles/pixel)"); ax.set_ylabel("Fake − real log power")
ax.set_title("(a) Spectral trace of each operator", loc="left", fontsize=7.5)
ax.legend(fontsize=5.8, frameon=False, loc="upper left")

# (b) alpha sweep (SPEC)
ax = axs[1]
alphas, ins, crs, ins_e, crs_e = [], [], [], [], []
for a in ["0.5", "0.7", "0.8", "0.9"]:
    path = f"{B}/out/results.json" if a == "0.8" else f"{B}/out_sweep_{a}/results.json"
    d = json.load(open(path)); m = collections.defaultdict(list)
    for r in d["cross_gen"]:
        if r["det"] == "SPEC":
            m[(r["seed"], r["train"] == r["test"])].append(r["auc"])
    seeds = sorted({k[0] for k in m})
    i = [np.mean(m[(s, True)]) for s in seeds]; c = [np.mean(m[(s, False)]) for s in seeds]
    alphas.append(float(a)); ins.append(np.mean(i)); crs.append(np.mean(c)); ins_e.append(np.std(i)); crs_e.append(np.std(c))
ax.errorbar(alphas, ins, yerr=ins_e, color="#333", marker="o", ms=3, lw=1, capsize=2, label="Same operator")
ax.errorbar(alphas, crs, yerr=crs_e, color="#CC79A7", marker="s", ms=3, lw=1, capsize=2, label="Unseen operators")
ax.axhline(0.5, color="#999", lw=0.5, ls=":")
ax.set_ylim(0.4, 1.02); ax.set_xlabel(r"Detail restored by generator, $\alpha$"); ax.set_ylabel("AUC (spectral detector)")
ax.set_title("(b) Transfer as fakes improve", loc="left", fontsize=7.5)
ax.legend(fontsize=6, frameon=False, loc="lower left")
json.dump({"alpha": alphas, "in": ins, "cross": crs, "in_sd": ins_e, "cross_sd": crs_e}, open(f"{B}/sweep_summary.json", "w"), indent=1)

# (c) JPEG robustness (train G1)
ax = axs[2]
m = collections.defaultdict(list)
for r in main["jpeg"]:
    m[(r["det"], r["train"], r["q"])].append(r["auc"])
qs = [100, 95, 90, 75, 50, 30]; xs = range(len(qs))
sty = {("SPEC", "clean"): ("#CC79A7", "-", "o"), ("SPEC", "jpeg-aug"): ("#CC79A7", "--", "o"),
       ("CNN", "clean"): ("#333333", "-", "s"), ("CNN", "jpeg-aug"): ("#333333", "--", "s")}
lab = {("SPEC", "clean"): "Spectral, clean training", ("SPEC", "jpeg-aug"): "Spectral, JPEG-augmented",
       ("CNN", "clean"): "CNN, clean training", ("CNN", "jpeg-aug"): "CNN, JPEG-augmented"}
summ = {}
for k, (c, ls, mk) in sty.items():
    mu = [np.mean(m[(k[0], k[1], q)]) for q in qs]; sd = [np.std(m[(k[0], k[1], q)]) for q in qs]
    summ[f"{k[0]}|{k[1]}"] = {"q": qs, "mean": mu, "sd": sd}
    ax.errorbar(xs, mu, yerr=sd, color=c, ls=ls, marker=mk, ms=3, lw=1, capsize=2, label=lab[k])
ax.set_xticks(list(xs)); ax.set_xticklabels(["none"] + [str(q) for q in qs[1:]])
ax.axhline(0.5, color="#999", lw=0.5, ls=":")
ax.set_ylim(0.4, 1.02); ax.set_xlabel("JPEG quality at test time"); ax.set_ylabel("AUC (train and test on G1)")
ax.set_title("(c) Effect of compression", loc="left", fontsize=7.5)
ax.legend(fontsize=5.8, frameon=False, loc="lower right")
json.dump(summ, open(f"{B}/jpeg_summary.json", "w"), indent=1)
fig.tight_layout(pad=0.3, w_pad=1.0)
fig.savefig(f"{OUT}/fig_experiment.pdf"); fig.savefig(f"{OUT}/fig_experiment.png")

# cross-generator table numbers
m = collections.defaultdict(list)
for r in main["cross_gen"]:
    m[(r["det"], r["train"], r["test"])].append(r["auc"])
tab = {f"{k[0]}|{k[1]}|{k[2]}": [round(float(np.mean(v)), 3), round(float(np.std(v)), 3)] for k, v in m.items()}
json.dump(tab, open(f"{B}/crossgen_summary.json", "w"), indent=1)
for k, v in sorted(tab.items()): print(k, v)
print(json.dumps(summ))
