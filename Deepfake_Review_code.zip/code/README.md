# Code and data for "Spatial, Temporal, or Both?"

Everything here reproduces the numbers in Sections VI and VII of the paper on a laptop CPU. No GPU and no deepfake dataset download are needed.

## 1. Matched-protocol benchmark (Section VI)

`reported.py` holds every published number used in Table III and Figs. 2–3, with the source table for each row, and computes the derived statistics (family means, ranges, generalization gaps, Spearman correlations, robustness losses, DeepfakeBench spreads).

```
python3 reported.py reported.json
python3 plot_reported.py reported.json ../paper/figs
```

Sources: LipForensics (Haliassos et al., CVPR 2021) Tables 2–4; RealForensics (Haliassos et al., CVPR 2022) Tables 2, 4, 7; FTCN (Zheng et al., ICCV 2021) Table 4; TALL (Xu et al., ICCV 2023) Tables 1, 3; DeepfakeBench (Yan et al., NeurIPS 2023) main results table.

## 2. Controlled up-sampling experiment (Section VII)

Needs the BSDS500 images (Arbelaez et al., TPAMI 2011), e.g. from https://github.com/BIDS/BSDS500.

```
pip install numpy scipy scikit-learn pillow torch matplotlib
git clone --depth 1 https://github.com/BIDS/BSDS500.git data/BSDS500
ALPHA=0.8 python3 freq_benchmark.py data/BSDS500 out            # main run, 3 seeds
for a in 0.5 0.7 0.9 1.0; do SPEC_ONLY=1 ALPHA=$a python3 freq_benchmark.py data/BSDS500 out_sweep_$a; done
python3 plot_exp.py . ../paper/figs
```

- Real class: 96x96 luminance crops of BSDS500 images.
- Fake class: another crop of the same image, down-sampled x2 and re-up-sampled with one of three operators (G1 transposed convolution, G2 resize-convolution, G3 bicubic), plus a fraction ALPHA of the true detail lost in down-sampling.
- Detectors: logistic regression on the azimuthally averaged log power spectrum (SPEC), and a small 4-block CNN.
- Train images (BSDS train+val, 300) and test images (BSDS test, 200) are disjoint.

`taxonomy` figure: `python3 plot_taxonomy.py ../paper/figs`.

## Included results

`results/` holds the raw `results.json` of every run reported in the paper (main run at ALPHA=0.8 with three seeds, and the spectral-only sweeps). To redraw Fig. 4 from them without re-running anything:

```
python3 plot_exp.py results figs
```

Runtime of the main run on a two-core CPU: about 7.5 minutes per seed. Note: at ALPHA=1.0 the bicubic (G3) fakes are identical to real crops by construction, so that sweep is kept for completeness but not plotted.
