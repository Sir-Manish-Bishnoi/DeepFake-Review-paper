"""
Controlled experiment: do frequency-domain upsampling traces generalise across
generators, and do they survive JPEG compression?

Real class : 96x96 luminance crops of BSDS500 images (pre-downscaled x2 with area
             averaging to remove the original JPEG block grid).
Fake class : a different crop of the same image, downscaled x2 and re-upsampled x2
             with one of three decoder-style operators:
               G1  transposed convolution (zero insertion + 3x3 kernel) -> checkerboard
               G2  nearest-neighbour resize + 3x3 smoothing conv (resize-convolution)
               G3  bicubic interpolation (smooth; weak high frequencies)
Detectors  : SPEC  azimuthally averaged log power spectrum + logistic regression
             CNN   small 4-block CNN on pixels
Splits     : BSDS train+val images -> training, BSDS test images -> testing (disjoint).
"""
import glob, io, json, os, sys, time
import numpy as np
from PIL import Image
from scipy import ndimage
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score
import torch, torch.nn as nn

ROOT = sys.argv[1]
OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
P = 96          # patch size
CROPS = 8       # crops per image (half real, half fake)
QUALS = [None, 95, 90, 75, 50, 30]
GENS = ["G1", "G2", "G3"]
torch.set_num_threads(2)


def load_lum(path):
    im = Image.open(path).convert("YCbCr").split()[0]
    w, h = im.size
    im = im.resize((w // 2, h // 2), Image.BOX)          # remove JPEG grid
    return np.asarray(im, dtype=np.float32)


K = np.array([[1, 3, 1], [3, 9, 3], [1, 3, 1]], np.float32) * (4.0 / 25.0)  # uneven overlap -> checkerboard (Odena et al.)
ALPHA = float(os.environ.get("ALPHA", "0.8"))  # fraction of true high-frequency detail the "generator" restores
SPEC_ONLY = os.environ.get("SPEC_ONLY") == "1"


def down2(x):
    return x.reshape(x.shape[0] // 2, 2, x.shape[1] // 2, 2).mean(axis=(1, 3))


def up(x, g):
    if g == "G1":                       # transposed conv, stride 2
        z = np.zeros((x.shape[0] * 2, x.shape[1] * 2), np.float32)
        z[::2, ::2] = x
        return ndimage.convolve(z, K, mode="reflect")
    if g == "G2":                       # resize-convolution
        z = np.repeat(np.repeat(x, 2, 0), 2, 1)
        return ndimage.convolve(z, np.full((3, 3), 1 / 9, np.float32), mode="reflect")
    if g == "G3":                       # bicubic
        im = Image.fromarray(x.astype(np.float32), mode="F")
        return np.asarray(im.resize((x.shape[1] * 2, x.shape[0] * 2), Image.BICUBIC), np.float32)
    raise ValueError(g)


def jpeg(x, q):
    if q is None:
        return x
    im = Image.fromarray(np.clip(x, 0, 255).astype(np.uint8))
    b = io.BytesIO(); im.save(b, "JPEG", quality=q)
    return np.asarray(Image.open(b), np.float32)


def make_split(paths, seed):
    rng = np.random.default_rng(seed)
    real, fake = [], {g: [] for g in GENS}
    for p in paths:
        img = load_lum(p)
        H, W = img.shape
        for c in range(CROPS):
            y = rng.integers(0, H - P); x = rng.integers(0, W - P)
            crop = img[y:y + P, x:x + P]
            if c % 2 == 0:
                real.append(crop)
            else:
                lo = down2(crop)
                hp = crop - up(lo, "G3")             # true detail lost by ideal-ish resampling
                for g in GENS:
                    fake[g].append(np.clip(up(lo, g) + ALPHA * hp, 0, 255))
    return np.stack(real), {g: np.stack(v) for g, v in fake.items()}


# ---------- spectral features ----------
yy, xx = np.indices((P, P)) - P // 2
RAD = np.sqrt(xx ** 2 + yy ** 2).astype(int)
NB = P // 2


def spec_feat(batch):
    out = []
    for x in batch:
        x = x - x.mean()
        f = np.fft.fftshift(np.abs(np.fft.fft2(x)) ** 2)
        lp = np.log(f + 1e-8)
        prof = np.bincount(RAD.ravel(), lp.ravel(), minlength=NB + 40)[:NB] / np.bincount(RAD.ravel(), minlength=NB + 40)[:NB]
        out.append(prof)
    return np.array(out, np.float32)


def spec_profile_mean(batch):
    return spec_feat(batch).mean(0)


# ---------- CNN ----------
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        ch = [1, 16, 32, 64, 64]
        layers = []
        for i in range(4):
            layers += [nn.Conv2d(ch[i], ch[i + 1], 3, padding=1), nn.BatchNorm2d(ch[i + 1]), nn.ReLU(), nn.MaxPool2d(2)]
        self.f = nn.Sequential(*layers)
        self.h = nn.Linear(64, 1)

    def forward(self, x):
        return self.h(self.f(x).mean((2, 3))).squeeze(1)


def to_t(a):
    return torch.from_numpy((a[:, None] - 127.5) / 127.5)


def train_cnn(Xr, Xf, seed, aug_jpeg=False, epochs=8):
    torch.manual_seed(seed); rng = np.random.default_rng(seed)
    X = np.concatenate([Xr, Xf]); y = np.r_[np.zeros(len(Xr)), np.ones(len(Xf))].astype(np.float32)
    net = Net(); opt = torch.optim.Adam(net.parameters(), 1e-3); lossf = nn.BCEWithLogitsLoss()
    for ep in range(epochs):
        idx = rng.permutation(len(X)); net.train()
        for i in range(0, len(X), 64):
            b = X[idx[i:i + 64]]
            if aug_jpeg:
                b = np.stack([jpeg(z, int(rng.choice([95, 90, 75, 50, 30]))) if rng.random() < 0.5 else z for z in b])
            if rng.random() < 0.5:
                b = b[:, :, ::-1].copy()
            opt.zero_grad(); l = lossf(net(to_t(b)), torch.from_numpy(y[idx[i:i + 64]])); l.backward(); opt.step()
    net.eval(); return net


def cnn_scores(net, X):
    with torch.no_grad():
        return np.concatenate([net(to_t(X[i:i + 256])).numpy() for i in range(0, len(X), 256)])


def train_spec(Xr, Xf, seed, aug_jpeg=False):
    rng = np.random.default_rng(seed)
    if aug_jpeg:
        Xr = np.stack([jpeg(z, int(rng.choice([95, 90, 75, 50, 30]))) if rng.random() < 0.5 else z for z in Xr])
        Xf = np.stack([jpeg(z, int(rng.choice([95, 90, 75, 50, 30]))) if rng.random() < 0.5 else z for z in Xf])
    F = np.concatenate([spec_feat(Xr), spec_feat(Xf)]); y = np.r_[np.zeros(len(Xr)), np.ones(len(Xf))]
    return make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, C=1.0)).fit(F, y)


def auc(sr, sf):
    return roc_auc_score(np.r_[np.zeros(len(sr)), np.ones(len(sf))], np.r_[sr, sf])


def main():
    d = os.path.join(ROOT, "BSDS500/data/images")
    tr = sorted(glob.glob(f"{d}/train/*.jpg") + glob.glob(f"{d}/val/*.jpg"))
    te = sorted(glob.glob(f"{d}/test/*.jpg"))
    print(len(tr), len(te), flush=True)
    seeds = [0, 1, 2]
    res = {"cross_gen": [], "jpeg": [], "meta": {"alpha": ALPHA, "train_images": len(tr), "test_images": len(te), "patch": P, "crops_per_image": CROPS}}
    profiles = None
    for s in seeds:
        t0 = time.time()
        Rtr, Ftr = make_split(tr, 100 + s); Rte, Fte = make_split(te, 200 + s)
        if s == 0:
            res["meta"]["n_train_real"] = len(Rtr); res["meta"]["n_train_fake_per_gen"] = len(Ftr["G1"])
            res["meta"]["n_test_real"] = len(Rte); res["meta"]["n_test_fake_per_gen"] = len(Fte["G1"])
            profiles = {"real": spec_profile_mean(Rte).tolist()}
            for g in GENS:
                profiles[g] = spec_profile_mean(Fte[g]).tolist()
            for q in [75, 50]:
                profiles[f"real_q{q}"] = spec_profile_mean(np.stack([jpeg(z, q) for z in Rte])).tolist()
                profiles[f"G1_q{q}"] = spec_profile_mean(np.stack([jpeg(z, q) for z in Fte["G1"]])).tolist()
        # E1: cross-generator matrix
        for gtr in GENS:
            sp = train_spec(Rtr, Ftr[gtr], s)
            sr_s = sp.decision_function(spec_feat(Rte))
            if not SPEC_ONLY:
                cn = train_cnn(Rtr, Ftr[gtr], s); sr_c = cnn_scores(cn, Rte)
            for gte in GENS:
                res["cross_gen"].append({"seed": s, "train": gtr, "test": gte, "det": "SPEC", "auc": auc(sr_s, sp.decision_function(spec_feat(Fte[gte])))})
                if not SPEC_ONLY:
                    res["cross_gen"].append({"seed": s, "train": gtr, "test": gte, "det": "CNN", "auc": auc(sr_c, cnn_scores(cn, Fte[gte]))})
            if gtr == "G1" and not SPEC_ONLY:
                # E2: JPEG robustness for clean-trained models (train G1)
                models = {("SPEC", "clean"): sp, ("CNN", "clean"): cn,
                          ("SPEC", "jpeg-aug"): train_spec(Rtr, Ftr["G1"], s, aug_jpeg=True),
                          ("CNN", "jpeg-aug"): train_cnn(Rtr, Ftr["G1"], s, aug_jpeg=True)}
                for q in QUALS:
                    Rq = np.stack([jpeg(z, q) for z in Rte]); Fq = np.stack([jpeg(z, q) for z in Fte["G1"]])
                    for (det, reg), m in models.items():
                        if det == "SPEC":
                            a = auc(m.decision_function(spec_feat(Rq)), m.decision_function(spec_feat(Fq)))
                        else:
                            a = auc(cnn_scores(m, Rq), cnn_scores(m, Fq))
                        res["jpeg"].append({"seed": s, "q": q if q else 100, "det": det, "train": reg, "auc": a})
        print(f"seed {s} done in {time.time()-t0:.0f}s", flush=True)
        json.dump({**res, "profiles": profiles}, open(os.path.join(OUT, "results.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
