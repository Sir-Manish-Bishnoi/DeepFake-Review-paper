"""Matched-protocol comparison of published results + derived statistics.

Every number is copied from a named table of a primary paper (see SOURCE fields).
Protocol V (video-level): train on FF++ (HQ / c23, all four manipulations), test video-level AUC
on Celeb-DF-v2, DFDC (LipForensics test subset, 3,215 videos before filtering), FaceShifter, DeeperForensics-1.0.
Protocol F (frame-level): DeepfakeBench, one codebase, train FF++ c23, frame-level AUC.
"""
import json, sys
import numpy as np
from scipy.stats import spearmanr

# name, family, CDF, DFDC, FSh, DFo, in-dataset FF++ HQ AUC (or None), source
V = [
 ("Xception",        "Frame (spatial)",              73.7, 70.9, 72.0, 84.5, 99.3, "LipF T2/T4"),
 ("CNN-aug",         "Frame (spatial)",              75.6, 72.1, 65.7, 74.4, 99.1, "LipF T2/T4"),
 ("Patch-based",     "Frame (spatial)",              69.6, 65.6, 57.8, 81.8, 97.2, "LipF T2/T4"),
 ("Face X-ray",      "Frame (spatial)",              79.5, 65.5, 92.8, 86.8, 97.8, "LipF T2/T4"),
 ("Multi-task",      "Frame (spatial)",              75.7, 68.1, 66.0, 77.7, None, "LipF T2"),
 ("DSP-FWA",         "Frame (spatial)",              69.5, 67.3, 65.5, 50.2, None, "LipF T2"),
 ("CNN-GRU",         "Temporal (recurrent/conv)",    69.8, 68.9, 80.8, 74.1, 99.3, "LipF T2/T4"),
 ("FTCN",            "Temporal (recurrent/conv)",    86.9, 74.0, 98.8, 98.8, None, "FTCN T4"),
 ("LipForensics",    "Temporal (behavioural)",       82.4, 73.5, 97.1, 97.6, 99.7, "LipF T2/T4"),
 ("RealForensics",   "Temporal (behavioural)",       86.9, 75.9, 99.7, 99.3, 99.8, "RealF T2/T7"),
 ("VTN",             "Spatio-temporal transformer",  83.2, 73.5, 98.7, 97.7, None, "TALL T-cross"),
 ("VidTR",           "Spatio-temporal transformer",  83.5, 73.3, 98.0, 97.9, None, "TALL T-cross"),
 ("ViViT",           "Spatio-temporal transformer",  86.96, 74.61, 99.41, 99.19, None, "TALL T-cross (reproduced)"),
 ("ISTVT",           "Spatio-temporal transformer",  84.1, 74.2, 99.3, 98.6, None, "TALL T-cross"),
 ("TALL-Swin",       "Spatio-temporal transformer",  90.79, 76.78, 99.67, 99.62, 99.87, "TALL T-cross/T-intra"),
]
# robustness: clean AUC, mean AUC over 7 corruptions x 5 severities (RealForensics Table 4, FF++ raw)
R = {"Xception": (99.8, 78.3), "CNN-aug": (99.8, 84.1), "Patch-based": (99.9, 67.5), "Face X-ray": (99.8, 77.5),
     "CNN-GRU": (99.9, 82.3), "LipForensics": (99.9, 92.5), "FTCN": (99.4, 89.5), "RealForensics": (99.8, 95.6)}
# DeepfakeBench frame-level AUC: FF++c23, CDFv2, DFDC
F = [("Meso4", "Naive", .6077, .6091, .5560), ("MesoIncep", "Naive", .7583, .6966, .6226), ("CNN-Aug", "Naive", .8493, .7027, .6361),
     ("Xception", "Naive", .9637, .7365, .7077), ("EfficientB4", "Naive", .9567, .7487, .6955), ("Capsule", "Spatial", .8421, .7472, .6465),
     ("FWA", "Spatial", .8765, .6680, .6132), ("Face X-ray", "Spatial", .9592, .6786, .6326), ("FFD", "Spatial", .9624, .7435, .7029),
     ("CORE", "Spatial", .9638, .7428, .7049), ("RECCE", "Spatial", .9621, .7319, .7133), ("UCF", "Spatial", .9705, .7527, .7191),
     ("F3Net", "Frequency", .9635, .7352, .7021), ("SPSL", "Frequency", .9610, .7650, .7040), ("SRM", "Frequency", .9576, .7552, .6995)]

out = {}
fam = {}
for n, f, *v, ind, s in V:
    fam.setdefault(f, []).append(v)
out["family_means"] = {f: dict(zip(["CDF", "DFDC", "FSh", "DFo", "Avg"], np.r_[np.mean(v, 0), np.mean(v)].round(1).tolist())) for f, v in fam.items()}
A = np.array([[r[2], r[3], r[4], r[5]] for r in V])
out["spread"] = {k: [float(A[:, i].min()), float(A[:, i].max()), round(float(A[:, i].max() - A[:, i].min()), 1)] for i, k in enumerate(["CDF", "DFDC", "FSh", "DFo"])}
out["avg4"] = {r[0]: round(float(np.mean(r[2:6])), 1) for r in V}
out["gap"] = {r[0]: {"in": r[6], "cdf_dfdc_mean": round((r[2] + r[3]) / 2, 2), "gap": round(r[6] - (r[2] + r[3]) / 2, 1)} for r in V if r[6]}
rho, p = spearmanr(A[:, 0], A[:, 1]); out["spearman_cdf_dfdc"] = [round(rho, 2), round(p, 4)]
rho, p = spearmanr(A[:, 2], A[:, 1]); out["spearman_fsh_dfdc"] = [round(rho, 2), round(p, 4)]
out["robust"] = {k: {"clean": c, "corr": m, "drop": round(c - m, 1)} for k, (c, m) in R.items()}
Fa = np.array([[x[2], x[3], x[4]] for x in F])
strong = Fa[Fa[:, 0] >= 0.95]
out["dfb_strong_n"] = int(len(strong))
out["dfb_strong_range"] = {"in": [float(strong[:, 0].min()), float(strong[:, 0].max())], "CDF": [float(strong[:, 1].min()), float(strong[:, 1].max())], "DFDC": [float(strong[:, 2].min()), float(strong[:, 2].max())]}
r1 = spearmanr(strong[:, 0], strong[:, 1]); r2 = spearmanr(strong[:, 0], strong[:, 2])
out["dfb_strong_spearman_in_vs_cdf"] = [round(r1[0], 2), round(r1[1], 3)]
out["dfb_strong_spearman_in_vs_dfdc"] = [round(r2[0], 2), round(r2[1], 3)]
r3 = spearmanr(Fa[:, 0], Fa[:, 1]); out["dfb_all_spearman_in_vs_cdf"] = [round(r3[0], 2), round(r3[1], 4)]
json.dump({"V": V, "R": R, "F": F, "stats": out}, open(sys.argv[1], "w"), indent=1)
print(json.dumps(out, indent=1))
