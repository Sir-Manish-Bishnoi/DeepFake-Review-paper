import json, sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = json.load(open(sys.argv[1])); OUT = sys.argv[2]
plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6, "savefig.dpi": 300})
FAM = {"Frame (spatial)": "#D55E00", "Temporal (recurrent/conv)": "#E69F00",
       "Temporal (behavioural)": "#0072B2", "Spatio-temporal transformer": "#009E73"}
SHORT = {"Frame (spatial)": "Frame-level spatial", "Temporal (recurrent/conv)": "Temporal (recurrent / 3D-conv)",
         "Temporal (behavioural)": "Temporal (behavioral pre-training)", "Spatio-temporal transformer": "Spatio-temporal transformer"}
V = d["V"]

# ---- Fig: strip plot per test set ----
fig, ax = plt.subplots(figsize=(3.45, 2.35))
sets = ["CDF", "DFDC", "FSh", "DFo"]; names = ["Celeb-DF-v2", "DFDC", "FaceShifter", "DeeperFor."]
fams = list(FAM)
for i in range(4):
    for r in V:
        fi = fams.index(r[1]); x = i + (fi - 1.5) * 0.13
        ax.scatter(x, r[2 + i], s=13, color=FAM[r[1]], edgecolor="white", linewidth=0.4, zorder=3)
    vals = [r[2 + i] for r in V]
    ax.plot([i - 0.32, i + 0.32], [max(vals)] * 2, color="#555", lw=0.6, ls=":")
    ax.text(i, 47.5, f"range {max(vals)-min(vals):.1f}", ha="center", fontsize=6.5, color="#444")
ax.set_xticks(range(4)); ax.set_xticklabels(names)
ax.set_ylabel("Video-level AUC (%)"); ax.set_ylim(45, 102); ax.axhline(50, color="#999", lw=0.5)
ax.grid(axis="y", lw=0.3, color="#ddd"); ax.set_axisbelow(True)
h = [plt.Line2D([], [], marker="o", ls="", color=c, markersize=4, label=SHORT[f]) for f, c in FAM.items()]
ax.legend(handles=h, fontsize=6, frameon=False, loc="lower left", bbox_to_anchor=(0.0, 0.08), handletextpad=0.2, borderaxespad=0)
fig.tight_layout(pad=0.3); fig.savefig(f"{OUT}/fig_crossdataset.pdf"); fig.savefig(f"{OUT}/fig_crossdataset.png")

# ---- Fig: two dumbbells ----
fig, axs = plt.subplots(1, 2, figsize=(7.1, 2.3))
g = d["stats"]["gap"]; fm = {r[0]: r[1] for r in V}
items = sorted(g.items(), key=lambda kv: kv[1]["gap"])
ax = axs[0]
for j, (n, v) in enumerate(items):
    c = FAM[fm[n]]
    ax.plot([v["cdf_dfdc_mean"], v["in"]], [j, j], color=c, lw=1.6, alpha=0.55)
    ax.scatter(v["in"], j, s=16, color="#333", zorder=3)
    ax.scatter(v["cdf_dfdc_mean"], j, s=18, color=c, zorder=3)
    ax.text(v["cdf_dfdc_mean"] - 0.8, j, f"−{v['gap']:.1f}", ha="right", va="center", fontsize=6.5, color="#333")
ax.set_yticks(range(len(items))); ax.set_yticklabels([n for n, _ in items]); ax.set_xlim(58, 101.5)
ax.set_xlabel("AUC (%)  [black: in-dataset; color: cross-dataset]")
ax.set_title("(a) Generalization gap", fontsize=8, loc="left")
ax.grid(axis="x", lw=0.3, color="#ddd"); ax.set_axisbelow(True)
ax = axs[1]
rb = sorted(d["stats"]["robust"].items(), key=lambda kv: kv[1]["drop"])
for j, (n, v) in enumerate(rb):
    c = FAM[fm[n]]
    ax.plot([v["corr"], v["clean"]], [j, j], color=c, lw=1.6, alpha=0.55)
    ax.scatter(v["clean"], j, s=16, color="#333", zorder=3)
    ax.scatter(v["corr"], j, s=18, color=c, zorder=3)
    ax.text(v["corr"] - 0.8, j, f"−{v['drop']:.1f}", ha="right", va="center", fontsize=6.5, color="#333")
ax.set_yticks(range(len(rb))); ax.set_yticklabels([n for n, _ in rb]); ax.set_xlim(58, 101.5)
ax.set_xlabel("AUC (%)  [black: clean; color: corrupted]")
ax.set_title("(b) Robustness to common corruptions", fontsize=8, loc="left")
ax.grid(axis="x", lw=0.3, color="#ddd"); ax.set_axisbelow(True)
fig.legend(handles=h, fontsize=6.5, frameon=False, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.02), columnspacing=1.0, handletextpad=0.2)
fig.tight_layout(pad=0.3, rect=(0, 0.07, 1, 1)); fig.savefig(f"{OUT}/fig_gap_robust.pdf"); fig.savefig(f"{OUT}/fig_gap_robust.png")
print("ok")
